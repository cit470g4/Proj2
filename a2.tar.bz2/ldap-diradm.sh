#!/bin/bash
#CIT-470 Project 2
#Instructor: Darci Guriel
#Team 4: Christopher Polly, Andrew Dahlenburg, Jakob Banta, Nischaya Shrestha
#Author: Christopher Polly
#Diradm Installation for LDAP Server
#Starts the Diradm installation for the LDAP Server and configures LDAP ACLs to allow password changes
#Starts the slapd service
systemctl start slapd >> ldap-conf.log
cd /usr/local
#Getting the diradm.conf file from the github link
wget https://raw.githubusercontent.com/alerque/diradm/master/diradm.conf >> ldap-conf.log
#Three sed commands that will change the BINDDN, USERBASE and GROUPBASE in the diradm.conf file
sed 's/BINDDN="cn=Admin,o=System"/BINDDN="cn=Manager,dc=cit470,dc=nku,dc=edu"/g' diradm.conf 
sed 's/USERBASE="ou=Users,ou=Accounts,o=System"/USERBASE="ou=People,dc=cit470,dc=nku,dc=edu"/g' diradm.conf 
sed 's/GROUPBASE="ou=Groups,ou=Accounts,o=System"/GROUPBASE="ou=Group,dc=cit470,dc=nku,dc=edu"/g' diradm.conf 
#Copying the diradm.conf file to the /etc/ directory
cp /usr/local/diradm.conf /etc/ >> ldap-conf.log
cd /etc/openldap/slapd.d/cn=config
#Adding the ACL's the the olcDatabase file
echo "olcAccess: {0} to attrs=userPassword, by self write by anonymous auth by * none" >> olcDatabase={2}hdb.ldif 
echo "olcAccess: {1} to * by self write by * read" >> olcDatabase={2}hdb.ldif 
#Restarting the slapd service to use our new configuration
systemctl restart slapd >> ldap-conf.log
