#!/bin/bash
#CIT-470 Project 2
#Instructor: Darci Guriel
#Team 4: Christopher Polly, Andrew Dahlenburg, Jakob Banta, Nischaya Shrestha
#Author: Christopher Polly
#Main NFS Server Install
#Starts the Main NFS Install and invokes other scripts to configure the NFS Server
if [ "$1" == "-h" ] || [ "$1" == "--help" ]
then
    echo "This Script will install and configure NFS to the server" | tee -a nfs-conf.log
else    
    echo "Starting the Install and Configuration for NFS" | tee -a nfs-conf.log
    chmod 755 nfs-conf.sh
    ./ldap-conf.sh
    echo "NFS Install and Configuration Finished!" | tee -a nfs-conf.log
    echo "Starting the Configuration of the Firewall for NFS" | tee -a nfs-conf.log
    chmod 755 nfs-firewall.sh
    ./nfs-firewall.sh
    echo "Firewall has been configured for NFS!" | tee -a nfs-conf.log
fi


    


