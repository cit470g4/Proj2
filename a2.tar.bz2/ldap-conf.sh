#!/bin/bash
#CIT-470 Project 2
#Instructor: Darci Guriel
#Team 4: Christopher Polly, Andrew Dahlenburg, Jakob Banta, Nischaya Shrestha
#Author: Christopher Polly
#LDAP Configuration
#Starts the Configuration of the LDAP Server. 
#Install LDAP and sed to the server
yum install openldap-servers openldap-clients iptables-services -y >> ldap-conf.log
#Goes into the ldap cn=config directory where the olcDatabase file is located
cd /etc/openldap/slapd.d/cn=config
#Makes a copy of the olcDatabase file
cp olcDatabase={2}hdb.ldif olcDatabase={2}hdb.ldif.org >> ldap-conf.log
#Command starts the ldap server 
systemctl start slapd.service >> ldap-conf.log
#Slappasswd command to genereate a hashed root password for our LDAP Server
echo cit470 >> file_name
slappasswd -h {SSHA} -T "file_name" > afile
echo -e "dn: olcDatabase={2}hdb,cn=config\nchangetype: modify\nreplace: olcSuffix\nolcSuffix: dc=cit470,dc=nku,dc=edu\n\ndn: olcDatabase={2}hdb,cn=config\nchangetype: modify\nreplace: olcRootDN\nolcRootDN: cn=Manager,dc=cit470,dc=nku,dc=edu\n\ndn: olcDatabase={2}hdb,cn=config\nchangetype: modify\nreplace: olcRootPW" > newfile.ldif
echo -n "olcRootPW: " >> newfile.ldif
echo $(cat afile) >> newfile.ldif
ldapmodify -Y EXTERNAL -H ldapi:/// -f newfile.ldif >> ldap-conf.log
#Command enables the ldap server to start on boot
systemctl enable slapd >> ldap-conf.log
sudo systemctl start iptables >> ldap-conf.log
sudo systemctl enable iptables >> ldap-conf.log
#Commands to modify the filewall to permit incoming packets to the LDAP port and allow our clients to be able to access the server with the iptables
systemctl start firewalld >> ldap-conf.log
firewall-cmd --zone=public --add-port=389/tcp --permanent >> ldap.log
firewall-cmd --zone=public --add-service=ldap --permanent >> ldap.log
firewall-cmd --zone=public --add-port=636/tcp --permanent >> ldap.log
sudo iptables -A INPUT -s 10.0.0.0/8 -j ACCEPT >> ldap.log
sudo service iptables save >> ldap.log
#Command reloads the firewall to update our firewall configuration
firewall-cmd --reload >> ldap.log 
systemctl stop slapd >> ldap.log
