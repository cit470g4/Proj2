#!/bin/bash
#CIT-470 Project 2
#Instructor: Darci Guriel
#Team 4: Christopher Polly, Andrew Dahlenburg, Jakob Banta, Nischaya Shrestha
#Author: Christopher Polly
#Main LDAP Server Install
#Starts the Main LDAP Install and invokes other scripts to configure the LDAP Server
if [ "$1" == "-h" ] || [ "$1" == "--help" ]
then
  echo "This Script will install and configure LDAP to the server" | tee -a ldap-conf.log
else
    echo "Starting the Install for LDAP" | tee -a ldap-conf.log
    chmod 755 ldap-conf.sh
    ./ldap-conf.sh
    echo "LDAP Install Finished!"
    echo "Setting up Authentication for LDAP" | tee -a ldap-conf.log
    chmod 755 ldap-auth.sh
    ./ldap-auth.sh
    echo "LDAP Authentication set up for LDAP!" | tee -a ldap-conf.log
    echo "Setting up diradm for LDAP"
    chmod 755 ldap-diradm.sh
    ./ldap-diradm.sh
    echo "Diradm for LDAP successfully set up!" | tee -a ldap-conf.log
fi




