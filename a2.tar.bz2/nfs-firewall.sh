#!/bin/bash
#CIT-470 Project 2
#Instructor: Darci Guriel
#Team 4: Christopher Polly, Andrew Dahlenburg, Jakob Banta, Nischaya Shrestha
#Author: Christopher Polly
#Script for NFS Firewall Configuration
#Sets up the Firewall for NFS

#Commands to add the ports required for the NFS Server and save our configurations to the firewall
firewall-cmd --zone=public --add-port=2049/tcp --permanent >> nfs-conf.log
firewall-cmd --zone=public --add-port=111/tcp --permanent >> nfs-conf.log
firewall-cmd --zone=public --add-port=20048/tcp --permanent >> nfs-conf.log
firewall-cmd --zone=public --add-port=2049/udp --permanent >> nfs-conf.log
firewall-cmd --zone=public --add-port=111/udp --permanent >> nfs-conf.log
firewall-cmd --zone=public --add-port=20048/udp --permanent >> nfs-conf.log
firewall-cmd --reload >> nfs-conf.log
#Adding a test user
useradd -c "Test User" -s /bin/bash -d /home/test -m test >> nfs-conf.log
passwd test <<EOF
cit470
cit470
EOF
