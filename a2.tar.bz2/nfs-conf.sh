#!/bin/bash
#CIT-470 Project 2
#Instructor: Darci Guriel
#Team 4: Christopher Polly, Andrew Dahlenburg, Jakob Banta, Nischaya Shrestha
#Author: Christopher Polly
#NFS Server Configuration
#Starts the NFS Server Configuration
#Installs nfs-utils for the NFS Server
yum install nfs-utils -y >> nfs-conf.log
#Creating the new partition
parted <<EOF
mkpart
primary
xfs
10.7GB
19.7GB
quit
EOF
#Command to make CentOS recognize the new partition
partprobe /dev/sda >> nfs-conf.log
#Format the new partition as an ext file system
mkfs.xfs /dev/sda3 >> nfs-conf.log
#Commands to mount the file system and umount /home
mount /dev/sda3 /home >> nfs-conf.log
umount /home >> nfs-conf.log
#Echo command to place our new partition into the /etc/fstab file
echo "/dev/sda3       /home        xfs   defaults 0 0" >> /etc/fstab
mount /dev/sda3 >> nfs-conf.log
#Systemctl commands to start and enable the NFS Server
systemctl start nfs >> nfs-conf.log
systemctl start nfs-lock >> nfs-conf.log
systemctl enable nfs >> nfs-conf.log
systemctl enable nfs-lock >> nfs-conf.log
#Echo command to export /home with r and w access
echo "/home 10.2.6.0/23(rw)" >> /etc/exports
exportfs -a >> nfs-conf.log
