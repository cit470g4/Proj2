#CIT-470 Project 2
#Instructor: Darci Guriel
#Team 4: Christopher Polly, Andrew Dahlenburg, Jakob Banta, Nischaya Shrestha

Main Scripts: install-ldap-server.sh and install-nfs-server.sh
Invokes other scripts to automate the install and configuration of the LDAP and NFS servers

Scripts that were called in the install-ldap-server.sh script:
ldap-conf
    This script handles the install and configuration of ldap and setting up the firewall and iptable.
ldap-auth
    This script configures authentication onto the ldap server. It will build our schemas and authenticate our clients.
ldap-diradm
    This script configures diradm onto the server. It will allow for changing of passwords and will set up ACLs in our olcDatabase file.

Scripts that were called in the install-nfs-server.sh script:
nfs-conf
    This script handles the install and configuration of nfs and setting up the new partition and home system for our network.
nfs-firewall
    This script handles the configuration of the firewall to allow the ports needed for nfs. 