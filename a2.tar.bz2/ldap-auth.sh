#!/bin/bash
#CIT-470 Project 2
#Instructor: Darci Guriel
#Team 4: Christopher Polly, Andrew Dahlenburg, Jakob Banta, Nischaya Shrestha
#Author: Christopher Polly
#Script for LDAP Authentication
#Starts the LDAP Authentication for the LDAP Server.
#Installs the necessary programs for the Authentication
yum install nss_ldap migrationtools sed -y >> ldap-conf.log
cd /var/lib/ldap
/bin/rm *
#Copying the DB_CONFIG.example file over to the DB_CONFIG directory
cp -f /usr/share/openldap-servers/DB_CONFIG.example /var/lib/ldap/DB_CONFIG >> ldap-conf.log
#Making LDAP the owner
chown -R ldap:ldap /var/lib/ldap >> ldap-conf.log
cd ~
#Copying our base.ldif file over to the migrationtools directory
cp -f base.ldif /usr/share/migrationtools >> ldap-conf.log
cd /usr/share/migrationtools
cp migrate_common.ph migrate_common.ph.org >> ldap-conf.log
#Two sed commands to change the DEFAULT_MAIL_DOMAIN and DEFAULT_BASE
sed -i 's/$DEFAULT_MAIL_DOMAIN = "padl.com";/$DEFAULT_MAIL_DOMAIN = "cit470.nku.edu";/g' migrate_common.ph 
sed -i 's/$DEFAULT_BASE = "dc=padl,dc=com";/$DEFAULT_BASE = "dc=cit470,dc=nku,dc=edu";/g' migrate_common.ph
systemctl start slapd >> ldap-conf.log
#Adding in all of our schemas using the ldapadd command
ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/core.ldif >> ldap-conf.log
ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/cosine.ldif >> ldap-conf.log
ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/nis.ldif >> ldap-conf.log
ldapadd -Y EXTERNAL -H ldapi:// -f /etc/openldap/schema/inetorgperson.ldif >> ldap-conf.log
systemctl stop slapd >> ldap-conf.log
chown -R ldap:ldap /var/lib/ldap >> ldap-conf.log
#Adding our base data and migrating the local passwd database and group database
slapadd -v -l base.ldif >> ldap-conf.log
./migrate_passwd.pl /etc/passwd > passwd.ldif >> ldap-conf.log
slapadd -v -l passwd.ldif >> ldap-conf.log
./migrate_group.pl /etc/group > group.ldif >> ldap-conf.log
slapadd -v -l group.ldif >> ldap-conf.log
chown -R ldap.ldap /var/lib/ldap >> ldap-conf.log
